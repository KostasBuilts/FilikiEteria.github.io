This is a web site created for a school class project

Its a translator from greek to an alphabet that greeks used to communicate
during their slavery times so that the turkish army wouldn't understand what they were writing to each other.
But that time the greek alphabet was a litlle different so the letters "η" "υ" dont exist. And you can not
use  this " ' ".
This project took some time and it's not finished cause i think it needs some more CSS. 
So it's at beta stage.
At this stage it's a proof of concept.



The creator
konstantinos kiriazis
